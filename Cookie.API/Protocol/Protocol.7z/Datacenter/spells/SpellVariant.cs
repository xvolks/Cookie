﻿// Generated on 12/06/2016 11:35:52

using System.Collections.Generic;
using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("SpellVariants")]
    public class SpellVariant : IDataObject
    {
        public const string MODULE = "SpellVariants";
        public int Id; //SpellVariant
        public int BreedId; //SpellVariant
        public List<int> SpellIds; //SpellVariant
    }
}