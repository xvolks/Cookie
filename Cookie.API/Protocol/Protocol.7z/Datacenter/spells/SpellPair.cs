// Generated on 12/06/2016 11:35:52

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("SpellPairs")]
    public class SpellPair : IDataObject
    {
        public const string MODULE = "SpellPairs";
        public uint DescriptionId;
        public int IconId;
        public int Id;
        public uint NameId;
    }
}