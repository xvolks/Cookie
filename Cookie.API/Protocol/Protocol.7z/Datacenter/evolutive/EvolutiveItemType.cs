﻿

// Generated on 12/06/2016 11:35:50
using System.Collections.Generic;
using Cookie.API.Gamedata.D2o;

namespace Cookie.Datacenter
{
    [D2oClass("EvolutiveItemTypes")]
    public class EvolutiveItemType : IDataObject
    {
        public const string MODULE = "EvolutiveItemTypes";
        public uint Id;
        public int MaxLevel;
        public double ExperienceBoost;
        public List<int> ExperienceByLevel;
    }
}