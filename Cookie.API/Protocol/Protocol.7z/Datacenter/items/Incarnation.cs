// Generated on 12/06/2016 11:35:50

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("Incarnation")]
    public class Incarnation : IDataObject
    {
        public const string MODULE = "Incarnation";
        public uint Id;
        public string LookFemale;
        public string LookMale;
    }
}