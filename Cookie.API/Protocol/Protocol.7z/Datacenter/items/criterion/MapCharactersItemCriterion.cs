// Generated on 12/06/2016 11:35:51

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("MapCharactersItemCriterion")]
    public class MapCharactersItemCriterion : ItemCriterion
    {
    }
}