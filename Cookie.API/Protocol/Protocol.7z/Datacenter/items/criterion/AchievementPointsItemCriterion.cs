﻿using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("AchievementPointsItemCriterion")]
    public class AchievementPointsItemCriterion : ItemCriterion
    {
    }
}