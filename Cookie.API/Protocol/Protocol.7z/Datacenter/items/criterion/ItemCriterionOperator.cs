// Generated on 12/06/2016 11:35:51

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("ItemCriterionOperator")]
    public class ItemCriterionOperator : IDataObject
    {
        public const string SUPERIOR = ">";
        public const string INFERIOR = "<";
        public const string EQUAL = "";
        public const string DIFFERENT = "!";
    }
}