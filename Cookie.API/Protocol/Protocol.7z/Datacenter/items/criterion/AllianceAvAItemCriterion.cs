// Generated on 12/06/2016 11:35:50

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("AllianceAvAItemCriterion")]
    public class AllianceAvAItemCriterion : ItemCriterion
    {
    }
}