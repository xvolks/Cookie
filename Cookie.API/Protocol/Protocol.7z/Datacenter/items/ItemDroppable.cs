﻿

// Generated on 12/06/2016 11:35:50
using System.Collections.Generic;
using Cookie.API.Gamedata.D2o;

namespace Cookie.Datacenter
{
    [D2oClass("ItemDroppables")]
    public class ItemDroppable : IDataObject
    {
        public const string MODULE = "ItemDroppables";
        public uint Id;
    }
}