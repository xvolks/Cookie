// Generated on 12/06/2016 11:35:50

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("ItemTypes")]
    public class ItemType : IDataObject
    {
        public const string MODULE = "ItemTypes";
        public int CraftXpRatio;
        public uint Gender;
        public int Id;
        public bool Mimickable;
        public uint NameId;
        public bool Plural;
        public string RawZone;
        public uint SuperTypeId;
        public int CategoryId; //ItemType
        public bool IsInEncyclopedia; //ItemType
        public int EvolutiveTypeId; //ItemType
    }
}