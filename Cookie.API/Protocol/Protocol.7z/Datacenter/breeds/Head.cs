// Generated on 12/06/2016 11:35:50

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("Heads")]
    public class Head : IDataObject
    {
        public const string MODULE = "Heads";
        public string AssetId;
        public uint Breed;
        public uint Gender;
        public int Id;
        public string Label;
        public uint Order;
        public string Skins;
    }
}