﻿// Generated on 12/06/2016 11:35:49

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("ArenaLeagues")]
    public class ArenaLeague : IDataObject
    {
        public const string MODULE = "ArenaLeagues";
        public uint Id;
        public uint NameId;
        public string Icon;
        public string Illus;
        public bool IsLastLeague;
        public int OrnamentId;
    }
}