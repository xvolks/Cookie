﻿// Generated on 12/06/2016 11:35:51

using System.Collections.Generic;
using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("MonsterDropCoefficients")]
    public class MonsterDropCoefficient : IDataObject
    {
        public const string MODULE = "MonsterDropCoefficients";
        public int Id;
        public int MonsterId; //MonsterDropCoefficient
        public int MonsterGrade; //MonsterDropCoefficient
        public double DropCoefficient; //MonsterDropCoefficient
        public string Criteria; //MonsterDropCoefficient
    }
}