// Generated on 12/06/2016 11:35:51

using Cookie.API.Gamedata.D2o;
using Cookie.API.Gamedata.D2o.other;

namespace Cookie.API.Datacenter
{
    [D2oClass("AnimFunMonsterData")]
    public class AnimFunMonsterData : AnimFunData
    {
    }
}