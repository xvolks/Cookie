﻿// Generated on 12/06/2016 11:35:52

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("Subhints")]
    public class Subhint : IDataObject
    {
        public const string MODULE = "Subhints";
        public int Hintid; //Subhint
        public string Hintparentuid; //Subhint
        public string Hintanchoredelement; //Subhint
        public int Hintanchor; //Subhint
        public int Hintpositionx; //Subhint
        public int Hintpositiony; //Subhint
        public int Hintwidth; //Subhint
        public int Hintheight; //Subhint
        public string Hinthighlightedelement; //Subhint
        public int Hintorder; //Subhint
        public int Hinttooltiptext; //Subhint
        public int Hinttooltippositionenum; //Subhint
        public string Hinttooltipurl; //Subhint
        public int Hinttooltipoffsetx; //Subhint
        public int Hinttooltipoffsety; //Subhint
        public int Hinttooltipwidth; //Subhint
        public double Hintcreationdate; //Subhint
    }
}