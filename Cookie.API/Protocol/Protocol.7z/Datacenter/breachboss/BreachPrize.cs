﻿// Generated on 12/06/2016 11:35:49
using Cookie.API.Gamedata.D2o;
using System.Collections.Generic;

namespace Cookie.Datacenter
{
    [D2oClass("BreachPrizes")]
    public class BreachPrize : IDataObject
    {
        public const string MODULE = "BreachPrizes";
        public int Id;
        public uint NameId;
        public uint CategoryId;
        public int currency;
        public string TooltipKey;
        public int DescriptionKey;
        public int ItemId;
    }
}