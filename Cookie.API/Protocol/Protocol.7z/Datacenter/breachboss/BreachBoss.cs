﻿// Generated on 12/06/2016 11:35:49
using Cookie.API.Gamedata.D2o;
using System.Collections.Generic;

namespace Cookie.Datacenter
{
    [D2oClass("BreachBoss")]
    public class BreachBoss : IDataObject
    {
        public const string MODULE = "BreachBoss";
        public int Id;
        public uint MonsterId;
        public uint Category;
        public string ApparitionCriterion;
        public string AccessCriterion;
        public uint MaxRewardQuantity;
        public List<int> IncompatibleBosses;
        public int RewardId;
    }
}