// Generated on 12/06/2016 11:35:49

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("CreatureBonesTypes")]
    public class CreatureBoneType : IDataObject
    {
        public const string MODULE = "CreatureBonesTypes";
        public int CreatureBoneId;
        public int Id;
    }
}