// Generated on 12/06/2016 11:35:50

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("EffectInstanceDate")]
    public class EffectInstanceDate : EffectInstance
    {
        public uint Day;
        public uint Hour;
        public uint Minute;
        public uint Month;
        public uint Year;
    }
}