// Generated on 12/06/2016 11:35:50

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("EffectInstanceInteger")]
    public class EffectInstanceInteger : EffectInstance
    {
        public const string MODULE = "EffectInstanceInteger";
        public int Value;
        public new int Dispellable; //effectinstanceinteger
        public new int SpellId; //effectinstanceinteger
        public new bool VisibleOnTerrain; //effectinstanceinteger
        public new bool ForClientOnly; //effectinstanceinteger
        public new int Order; //effectinstanceinteger
    }
}