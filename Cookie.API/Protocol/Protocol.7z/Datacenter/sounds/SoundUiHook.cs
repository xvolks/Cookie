// Generated on 12/06/2016 11:35:52

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("SoundUiHook")]
    public class SoundUiHook : IDataObject
    {
        public uint Id;
        public string MODULE = "SoundUiHook";
        public string Name;
    }
}