// Generated on 12/06/2016 11:35:50

using Cookie.API.Gamedata.D2o;

namespace Cookie.API.Datacenter
{
    [D2oClass("DareCriterias")]
    public class DareCriteria : IDataObject
    {
        public const string MODULE = "DareCriterias";
        public uint Id;
        public uint MaxOccurence;
        public int MaxParameterBound;
        public uint MaxParameters;
        public int MinParameterBound;
        public uint NameId;
    }
}