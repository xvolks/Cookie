﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class GameServerInformations : NetworkType
    {
        public const ushort ProtocolId = 25;
        public override ushort TypeID => ProtocolId;
        public bool IsMonoAccount { get; set; }
        public bool IsSelectable { get; set; }
        public ushort ObjectId { get; set; }
        public sbyte Type { get; set; }
        public byte Status { get; set; }
        public byte Completion { get; set; }
        public byte CharactersCount { get; set; }
        public byte CharactersSlots { get; set; }
        public double Date { get; set; }

        public GameServerInformations(bool isMonoAccount, bool isSelectable, ushort objectId, sbyte type, byte status, byte completion, byte charactersCount, byte charactersSlots, double date)
        {
            IsMonoAccount = isMonoAccount;
            IsSelectable = isSelectable;
            ObjectId = objectId;
            Type = type;
            Status = status;
            Completion = completion;
            CharactersCount = charactersCount;
            CharactersSlots = charactersSlots;
            Date = date;
        }

        public GameServerInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            var flag = new byte();
            flag = BooleanByteWrapper.SetFlag(0, flag, IsMonoAccount);
            flag = BooleanByteWrapper.SetFlag(1, flag, IsSelectable);
            writer.WriteByte(flag);
            writer.WriteVarUhShort(ObjectId);
            writer.WriteSByte(Type);
            writer.WriteByte(Status);
            writer.WriteByte(Completion);
            writer.WriteByte(CharactersCount);
            writer.WriteByte(CharactersSlots);
            writer.WriteDouble(Date);
        }

        public override void Deserialize(IDataReader reader)
        {
            var flag = reader.ReadByte();
            IsMonoAccount = BooleanByteWrapper.GetFlag(flag, 0);
            IsSelectable = BooleanByteWrapper.GetFlag(flag, 1);
            ObjectId = reader.ReadVarUhShort();
            Type = reader.ReadSByte();
            Status = reader.ReadByte();
            Completion = reader.ReadByte();
            CharactersCount = reader.ReadByte();
            CharactersSlots = reader.ReadByte();
            Date = reader.ReadDouble();
        }

    }
}
