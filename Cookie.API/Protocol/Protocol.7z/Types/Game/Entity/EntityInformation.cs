﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class EntityInformation : NetworkType
    {
        public const ushort ProtocolId = 546;
        public override ushort TypeID => ProtocolId;
        public ushort ObjectId { get; set; }
        public uint Experience { get; set; }
        public bool Status { get; set; }

        public EntityInformation(ushort objectId, uint experience, bool status)
        {
            ObjectId = objectId;
            Experience = experience;
            Status = status;
        }

        public EntityInformation() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhShort(ObjectId);
            writer.WriteVarUhInt(Experience);
            writer.WriteBoolean(Status);
        }

        public override void Deserialize(IDataReader reader)
        {
            ObjectId = reader.ReadVarUhShort();
            Experience = reader.ReadVarUhInt();
            Status = reader.ReadBoolean();
        }

    }
}
