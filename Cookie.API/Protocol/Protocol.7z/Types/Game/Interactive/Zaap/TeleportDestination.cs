﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class TeleportDestination : NetworkType
    {
        public const ushort ProtocolId = 563;
        public override ushort TypeID => ProtocolId;
        public byte Type { get; set; }
        public double MapId { get; set; }
        public ushort SubAreaId { get; set; }
        public ushort Level { get; set; }
        public ushort Cost { get; set; }

        public TeleportDestination(byte type, double mapId, ushort subAreaId, ushort level, ushort cost)
        {
            Type = type;
            MapId = mapId;
            SubAreaId = subAreaId;
            Level = level;
            Cost = cost;
        }

        public TeleportDestination() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteByte(Type);
            writer.WriteDouble(MapId);
            writer.WriteVarUhShort(SubAreaId);
            writer.WriteVarUhShort(Level);
            writer.WriteVarUhShort(Cost);
        }

        public override void Deserialize(IDataReader reader)
        {
            Type = reader.ReadByte();
            MapId = reader.ReadDouble();
            SubAreaId = reader.ReadVarUhShort();
            Level = reader.ReadVarUhShort();
            Cost = reader.ReadVarUhShort();
        }

    }
}
