﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class FriendSpouseInformations : NetworkType
    {
        public const ushort ProtocolId = 77;
        public override ushort TypeID => ProtocolId;
        public int SpouseAccountId { get; set; }
        public ulong SpouseId { get; set; }
        public string SpouseName { get; set; }
        public ushort SpouseLevel { get; set; }
        public sbyte Breed { get; set; }
        public sbyte Sex { get; set; }
        public EntityLook SpouseEntityLook { get; set; }
        public GuildInformations GuildInfo { get; set; }
        public sbyte AlignmentSide { get; set; }

        public FriendSpouseInformations(int spouseAccountId, ulong spouseId, string spouseName, ushort spouseLevel, sbyte breed, sbyte sex, EntityLook spouseEntityLook, GuildInformations guildInfo, sbyte alignmentSide)
        {
            SpouseAccountId = spouseAccountId;
            SpouseId = spouseId;
            SpouseName = spouseName;
            SpouseLevel = spouseLevel;
            Breed = breed;
            Sex = sex;
            SpouseEntityLook = spouseEntityLook;
            GuildInfo = guildInfo;
            AlignmentSide = alignmentSide;
        }

        public FriendSpouseInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteInt(SpouseAccountId);
            writer.WriteVarUhLong(SpouseId);
            writer.WriteUTF(SpouseName);
            writer.WriteVarUhShort(SpouseLevel);
            writer.WriteSByte(Breed);
            writer.WriteSByte(Sex);
            SpouseEntityLook.Serialize(writer);
            GuildInfo.Serialize(writer);
            writer.WriteSByte(AlignmentSide);
        }

        public override void Deserialize(IDataReader reader)
        {
            SpouseAccountId = reader.ReadInt();
            SpouseId = reader.ReadVarUhLong();
            SpouseName = reader.ReadUTF();
            SpouseLevel = reader.ReadVarUhShort();
            Breed = reader.ReadSByte();
            Sex = reader.ReadSByte();
            SpouseEntityLook = new EntityLook();
            SpouseEntityLook.Deserialize(reader);
            GuildInfo = new GuildInformations();
            GuildInfo.Deserialize(reader);
            AlignmentSide = reader.ReadSByte();
        }

    }
}
