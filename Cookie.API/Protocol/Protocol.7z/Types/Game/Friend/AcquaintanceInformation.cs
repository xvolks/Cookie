﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class AcquaintanceInformation : AbstractContactInformations
    {
        public new const ushort ProtocolId = 561;
        public override ushort TypeID => ProtocolId;
        public byte PlayerState { get; set; }

        public AcquaintanceInformation(byte playerState)
        {
            PlayerState = playerState;
        }

        public AcquaintanceInformation() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteByte(PlayerState);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            PlayerState = reader.ReadByte();
        }

    }
}
