﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class PaddockBuyableInformations : NetworkType
    {
        public const ushort ProtocolId = 130;
        public override ushort TypeID => ProtocolId;
        public ulong Price { get; set; }
        public bool Locked { get; set; }

        public PaddockBuyableInformations(ulong price, bool locked)
        {
            Price = price;
            Locked = locked;
        }

        public PaddockBuyableInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhLong(Price);
            writer.WriteBoolean(Locked);
        }

        public override void Deserialize(IDataReader reader)
        {
            Price = reader.ReadVarUhLong();
            Locked = reader.ReadBoolean();
        }

    }
}
