﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class PlayerStatus : NetworkType
    {
        public const ushort ProtocolId = 415;
        public override ushort TypeID => ProtocolId;
        public byte StatusId { get; set; }

        public PlayerStatus(byte statusId)
        {
            StatusId = statusId;
        }

        public PlayerStatus() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteByte(StatusId);
        }

        public override void Deserialize(IDataReader reader)
        {
            StatusId = reader.ReadByte();
        }

    }
}
