﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class AchievementObjective : NetworkType
    {
        public const ushort ProtocolId = 404;
        public override ushort TypeID => ProtocolId;
        public uint ObjectId { get; set; }
        public uint MaxValue { get; set; }

        public AchievementObjective(uint objectId, uint maxValue)
        {
            ObjectId = objectId;
            MaxValue = maxValue;
        }

        public AchievementObjective() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhInt(ObjectId);
            writer.WriteVarUhInt(MaxValue);
        }

        public override void Deserialize(IDataReader reader)
        {
            ObjectId = reader.ReadVarUhInt();
            MaxValue = reader.ReadVarUhInt();
        }

    }
}
