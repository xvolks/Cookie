﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class ObjectEffectDice : ObjectEffect
    {
        public new const ushort ProtocolId = 73;
        public override ushort TypeID => ProtocolId;
        public uint DiceNum { get; set; }
        public uint DiceSide { get; set; }
        public uint DiceConst { get; set; }

        public ObjectEffectDice(uint diceNum, uint diceSide, uint diceConst)
        {
            DiceNum = diceNum;
            DiceSide = diceSide;
            DiceConst = diceConst;
        }

        public ObjectEffectDice() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteVarUhInt(DiceNum);
            writer.WriteVarUhInt(DiceSide);
            writer.WriteVarUhInt(DiceConst);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            DiceNum = reader.ReadVarUhInt();
            DiceSide = reader.ReadVarUhInt();
            DiceConst = reader.ReadVarUhInt();
        }

    }
}
