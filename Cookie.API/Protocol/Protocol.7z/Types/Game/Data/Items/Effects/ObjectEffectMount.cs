﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class ObjectEffectMount : ObjectEffect
    {
        public new const ushort ProtocolId = 179;
        public override ushort TypeID => ProtocolId;
        public bool Sex { get; set; }
        public bool IsRideable { get; set; }
        public bool IsFeconded { get; set; }
        public bool IsFecondationReady { get; set; }
        public ulong ObjectId { get; set; }
        public ulong ExpirationDate { get; set; }
        public uint Model { get; set; }
        public string Name { get; set; }
        public string Owner { get; set; }
        public byte Level { get; set; }
        public int ReproductionCount { get; set; }
        public uint ReproductionCountMax { get; set; }
        public List<ObjectEffectInteger> Effects { get; set; }
        public List<uint> Capacities { get; set; }

        public ObjectEffectMount(bool sex, bool isRideable, bool isFeconded, bool isFecondationReady, ulong objectId, ulong expirationDate, uint model, string name, string owner, byte level, int reproductionCount, uint reproductionCountMax, List<ObjectEffectInteger> effects, List<uint> capacities)
        {
            Sex = sex;
            IsRideable = isRideable;
            IsFeconded = isFeconded;
            IsFecondationReady = isFecondationReady;
            ObjectId = objectId;
            ExpirationDate = expirationDate;
            Model = model;
            Name = name;
            Owner = owner;
            Level = level;
            ReproductionCount = reproductionCount;
            ReproductionCountMax = reproductionCountMax;
            Effects = effects;
            Capacities = capacities;
        }

        public ObjectEffectMount() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            var flag = new byte();
            flag = BooleanByteWrapper.SetFlag(0, flag, Sex);
            flag = BooleanByteWrapper.SetFlag(1, flag, IsRideable);
            flag = BooleanByteWrapper.SetFlag(2, flag, IsFeconded);
            flag = BooleanByteWrapper.SetFlag(3, flag, IsFecondationReady);
            writer.WriteByte(flag);
            writer.WriteVarUhLong(ObjectId);
            writer.WriteVarUhLong(ExpirationDate);
            writer.WriteVarUhInt(Model);
            writer.WriteUTF(Name);
            writer.WriteUTF(Owner);
            writer.WriteByte(Level);
            writer.WriteVarInt(ReproductionCount);
            writer.WriteVarUhInt(ReproductionCountMax);
            writer.WriteShort((short)Effects.Count);
            for (var effectsIndex = 0; effectsIndex < Effects.Count; effectsIndex++)
            {
                var objectToSend = Effects[effectsIndex];
                objectToSend.Serialize(writer);
            }
            writer.WriteShort((short)Capacities.Count);
            for (var capacitiesIndex = 0; capacitiesIndex < Capacities.Count; capacitiesIndex++)
            {
                writer.WriteVarUhInt(Capacities[capacitiesIndex]);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            var flag = reader.ReadByte();
            Sex = BooleanByteWrapper.GetFlag(flag, 0);
            IsRideable = BooleanByteWrapper.GetFlag(flag, 1);
            IsFeconded = BooleanByteWrapper.GetFlag(flag, 2);
            IsFecondationReady = BooleanByteWrapper.GetFlag(flag, 3);
            ObjectId = reader.ReadVarUhLong();
            ExpirationDate = reader.ReadVarUhLong();
            Model = reader.ReadVarUhInt();
            Name = reader.ReadUTF();
            Owner = reader.ReadUTF();
            Level = reader.ReadByte();
            ReproductionCount = reader.ReadVarInt();
            ReproductionCountMax = reader.ReadVarUhInt();
            var effectsCount = reader.ReadUShort();
            Effects = new List<ObjectEffectInteger>();
            for (var effectsIndex = 0; effectsIndex < effectsCount; effectsIndex++)
            {
                var objectToAdd = new ObjectEffectInteger();
                objectToAdd.Deserialize(reader);
                Effects.Add(objectToAdd);
            }
            var capacitiesCount = reader.ReadUShort();
            Capacities = new List<uint>();
            for (var capacitiesIndex = 0; capacitiesIndex < capacitiesCount; capacitiesIndex++)
            {
                Capacities.Add(reader.ReadVarUhInt());
            }
        }

    }
}
