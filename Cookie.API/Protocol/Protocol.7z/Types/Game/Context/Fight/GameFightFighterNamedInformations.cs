﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class GameFightFighterNamedInformations : GameFightFighterInformations
    {
        public new const ushort ProtocolId = 158;
        public override ushort TypeID => ProtocolId;
        public string Name { get; set; }
        public PlayerStatus Status { get; set; }
        public short LeagueId { get; set; }
        public int LadderPosition { get; set; }
        public bool HiddenInPrefight { get; set; }

        public GameFightFighterNamedInformations(string name, PlayerStatus status, short leagueId, int ladderPosition, bool hiddenInPrefight)
        {
            Name = name;
            Status = status;
            LeagueId = leagueId;
            LadderPosition = ladderPosition;
            HiddenInPrefight = hiddenInPrefight;
        }

        public GameFightFighterNamedInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteUTF(Name);
            Status.Serialize(writer);
            writer.WriteVarShort(LeagueId);
            writer.WriteInt(LadderPosition);
            writer.WriteBoolean(HiddenInPrefight);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            Name = reader.ReadUTF();
            Status = new PlayerStatus();
            Status.Deserialize(reader);
            LeagueId = reader.ReadVarShort();
            LadderPosition = reader.ReadInt();
            HiddenInPrefight = reader.ReadBoolean();
        }

    }
}
