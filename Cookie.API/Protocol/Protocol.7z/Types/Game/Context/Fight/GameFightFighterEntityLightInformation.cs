﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class GameFightFighterEntityLightInformation : GameFightFighterLightInformations
    {
        public new const ushort ProtocolId = 548;
        public override ushort TypeID => ProtocolId;
        public byte EntityModelId { get; set; }
        public double MasterId { get; set; }

        public GameFightFighterEntityLightInformation(byte entityModelId, double masterId)
        {
            EntityModelId = entityModelId;
            MasterId = masterId;
        }

        public GameFightFighterEntityLightInformation() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteByte(EntityModelId);
            writer.WriteDouble(MasterId);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            EntityModelId = reader.ReadByte();
            MasterId = reader.ReadDouble();
        }

    }
}
