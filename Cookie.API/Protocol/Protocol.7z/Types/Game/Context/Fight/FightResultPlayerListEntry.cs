﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class FightResultPlayerListEntry : FightResultFighterListEntry
    {
        public new const ushort ProtocolId = 24;
        public override ushort TypeID => ProtocolId;
        public ushort Level { get; set; }
        public List<FightResultAdditionalData> Additional { get; set; }

        public FightResultPlayerListEntry(ushort level, List<FightResultAdditionalData> additional)
        {
            Level = level;
            Additional = additional;
        }

        public FightResultPlayerListEntry() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteVarUhShort(Level);
            writer.WriteShort((short)Additional.Count);
            for (var additionalIndex = 0; additionalIndex < Additional.Count; additionalIndex++)
            {
                var objectToSend = Additional[additionalIndex];
                writer.WriteUShort(objectToSend.TypeID);
                objectToSend.Serialize(writer);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            Level = reader.ReadVarUhShort();
            var additionalCount = reader.ReadUShort();
            Additional = new List<FightResultAdditionalData>();
            for (var additionalIndex = 0; additionalIndex < additionalCount; additionalIndex++)
            {
                var objectToAdd = ProtocolTypeManager.GetInstance<FightResultAdditionalData>(reader.ReadUShort());
                objectToAdd.Deserialize(reader);
                Additional.Add(objectToAdd);
            }
        }

    }
}
