﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class GameFightMonsterInformations : GameFightAIInformations
    {
        public new const ushort ProtocolId = 29;
        public override ushort TypeID => ProtocolId;
        public ushort CreatureGenericId { get; set; }
        public byte CreatureGrade { get; set; }
        public short CreatureLevel { get; set; }

        public GameFightMonsterInformations(ushort creatureGenericId, byte creatureGrade, short creatureLevel)
        {
            CreatureGenericId = creatureGenericId;
            CreatureGrade = creatureGrade;
            CreatureLevel = creatureLevel;
        }

        public GameFightMonsterInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteVarUhShort(CreatureGenericId);
            writer.WriteByte(CreatureGrade);
            writer.WriteShort(CreatureLevel);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            CreatureGenericId = reader.ReadVarUhShort();
            CreatureGrade = reader.ReadByte();
            CreatureLevel = reader.ReadShort();
        }

    }
}
