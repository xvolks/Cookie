﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class FightLoot : NetworkType
    {
        public const ushort ProtocolId = 41;
        public override ushort TypeID => ProtocolId;
        public List<uint> Objects { get; set; }
        public ulong Kamas { get; set; }

        public FightLoot(List<uint> objects, ulong kamas)
        {
            Objects = objects;
            Kamas = kamas;
        }

        public FightLoot() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteShort((short)Objects.Count);
            for (var objectsIndex = 0; objectsIndex < Objects.Count; objectsIndex++)
            {
                writer.WriteVarUhInt(Objects[objectsIndex]);
            }
            writer.WriteVarUhLong(Kamas);
        }

        public override void Deserialize(IDataReader reader)
        {
            var objectsCount = reader.ReadUShort();
            Objects = new List<uint>();
            for (var objectsIndex = 0; objectsIndex < objectsCount; objectsIndex++)
            {
                Objects.Add(reader.ReadVarUhInt());
            }
            Kamas = reader.ReadVarUhLong();
        }

    }
}
