﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class GameFightEntityInformation : GameFightFighterInformations
    {
        public new const ushort ProtocolId = 551;
        public override ushort TypeID => ProtocolId;
        public byte EntityModelId { get; set; }
        public ushort Level { get; set; }
        public double MasterId { get; set; }

        public GameFightEntityInformation(byte entityModelId, ushort level, double masterId)
        {
            EntityModelId = entityModelId;
            Level = level;
            MasterId = masterId;
        }

        public GameFightEntityInformation() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteByte(EntityModelId);
            writer.WriteVarUhShort(Level);
            writer.WriteDouble(MasterId);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            EntityModelId = reader.ReadByte();
            Level = reader.ReadVarUhShort();
            MasterId = reader.ReadDouble();
        }

    }
}
