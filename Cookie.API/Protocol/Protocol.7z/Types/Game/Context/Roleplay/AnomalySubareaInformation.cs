﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class AnomalySubareaInformation : NetworkType
    {
        public const ushort ProtocolId = 565;
        public override ushort TypeID => ProtocolId;
        public ushort SubAreaId { get; set; }
        public short RewardRate { get; set; }
        public bool HasAnomaly { get; set; }
        public ulong AnomalyClosingTime { get; set; }

        public AnomalySubareaInformation(ushort subAreaId, short rewardRate, bool hasAnomaly, ulong anomalyClosingTime)
        {
            SubAreaId = subAreaId;
            RewardRate = rewardRate;
            HasAnomaly = hasAnomaly;
            AnomalyClosingTime = anomalyClosingTime;
        }

        public AnomalySubareaInformation() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhShort(SubAreaId);
            writer.WriteVarShort(RewardRate);
            writer.WriteBoolean(HasAnomaly);
            writer.WriteVarUhLong(AnomalyClosingTime);
        }

        public override void Deserialize(IDataReader reader)
        {
            SubAreaId = reader.ReadVarUhShort();
            RewardRate = reader.ReadVarShort();
            HasAnomaly = reader.ReadBoolean();
            AnomalyClosingTime = reader.ReadVarUhLong();
        }

    }
}
