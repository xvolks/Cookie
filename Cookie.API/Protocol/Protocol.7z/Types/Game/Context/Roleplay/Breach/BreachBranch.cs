﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class BreachBranch : NetworkType
    {
        public const ushort ProtocolId = 558;
        public override ushort TypeID => ProtocolId;
        public byte Room { get; set; }
        public int Element { get; set; }
        public List<MonsterInGroupLightInformations> Bosses { get; set; }
        public double Map { get; set; }

        public BreachBranch(byte room, int element, List<MonsterInGroupLightInformations> bosses, double map)
        {
            Room = room;
            Element = element;
            Bosses = bosses;
            Map = map;
        }

        public BreachBranch() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteByte(Room);
            writer.WriteInt(Element);
            writer.WriteShort((short)Bosses.Count);
            for (var bossesIndex = 0; bossesIndex < Bosses.Count; bossesIndex++)
            {
                var objectToSend = Bosses[bossesIndex];
                objectToSend.Serialize(writer);
            }
            writer.WriteDouble(Map);
        }

        public override void Deserialize(IDataReader reader)
        {
            Room = reader.ReadByte();
            Element = reader.ReadInt();
            var bossesCount = reader.ReadUShort();
            Bosses = new List<MonsterInGroupLightInformations>();
            for (var bossesIndex = 0; bossesIndex < bossesCount; bossesIndex++)
            {
                var objectToAdd = new MonsterInGroupLightInformations();
                objectToAdd.Deserialize(reader);
                Bosses.Add(objectToAdd);
            }
            Map = reader.ReadDouble();
        }

    }
}
