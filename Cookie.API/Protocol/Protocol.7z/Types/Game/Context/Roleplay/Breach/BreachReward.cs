﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class BreachReward : NetworkType
    {
        public const ushort ProtocolId = 559;
        public override ushort TypeID => ProtocolId;
        public uint ObjectId { get; set; }
        public List<byte> BuyLocks { get; set; }
        public string BuyCriterion { get; set; }
        public bool Bought { get; set; }
        public uint Price { get; set; }

        public BreachReward(uint objectId, List<byte> buyLocks, string buyCriterion, bool bought, uint price)
        {
            ObjectId = objectId;
            BuyLocks = buyLocks;
            BuyCriterion = buyCriterion;
            Bought = bought;
            Price = price;
        }

        public BreachReward() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhInt(ObjectId);
            writer.WriteShort((short)BuyLocks.Count);
            for (var buyLocksIndex = 0; buyLocksIndex < BuyLocks.Count; buyLocksIndex++)
            {
                writer.WriteByte(BuyLocks[buyLocksIndex]);
            }
            writer.WriteUTF(BuyCriterion);
            writer.WriteBoolean(Bought);
            writer.WriteVarUhInt(Price);
        }

        public override void Deserialize(IDataReader reader)
        {
            ObjectId = reader.ReadVarUhInt();
            var buyLocksCount = reader.ReadUShort();
            BuyLocks = new List<byte>();
            for (var buyLocksIndex = 0; buyLocksIndex < buyLocksCount; buyLocksIndex++)
            {
                BuyLocks.Add(reader.ReadByte());
            }
            BuyCriterion = reader.ReadUTF();
            Bought = reader.ReadBoolean();
            Price = reader.ReadVarUhInt();
        }

    }
}
