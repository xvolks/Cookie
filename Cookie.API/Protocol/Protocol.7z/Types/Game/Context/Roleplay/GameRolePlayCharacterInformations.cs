﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class GameRolePlayCharacterInformations : GameRolePlayHumanoidInformations
    {
        public new const ushort ProtocolId = 36;
        public override ushort TypeID => ProtocolId;
        public ActorAlignmentInformations AlignmentInfos { get; set; }
        public uint Speed { get; set; }

        public GameRolePlayCharacterInformations(ActorAlignmentInformations alignmentInfos, uint speed)
        {
            AlignmentInfos = alignmentInfos;
            Speed = speed;
        }

        public GameRolePlayCharacterInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            AlignmentInfos.Serialize(writer);
            writer.WriteUInt(Speed);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            AlignmentInfos = new ActorAlignmentInformations();
            AlignmentInfos.Deserialize(reader);
            Speed = reader.ReadUInt();
        }

    }
}
