﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class ArenaRankInfos : NetworkType
    {
        public const ushort ProtocolId = 499;
        public override ushort TypeID => ProtocolId;
        public ArenaRanking Ranking { get; set; }
        public ArenaLeagueRanking LeagueRanking { get; set; }
        public ushort VictoryCount { get; set; }
        public ushort Fightcount { get; set; }
        public short NumFightNeededForLadder { get; set; }

        public ArenaRankInfos(ArenaRanking ranking, ArenaLeagueRanking leagueRanking, ushort victoryCount, ushort fightcount, short numFightNeededForLadder)
        {
            Ranking = ranking;
            LeagueRanking = leagueRanking;
            VictoryCount = victoryCount;
            Fightcount = fightcount;
            NumFightNeededForLadder = numFightNeededForLadder;
        }

        public ArenaRankInfos() { }

        public override void Serialize(IDataWriter writer)
        {
            Ranking.Serialize(writer);
            LeagueRanking.Serialize(writer);
            writer.WriteVarUhShort(VictoryCount);
            writer.WriteVarUhShort(Fightcount);
            writer.WriteShort(NumFightNeededForLadder);
        }

        public override void Deserialize(IDataReader reader)
        {
            Ranking = new ArenaRanking();
            Ranking.Deserialize(reader);
            LeagueRanking = new ArenaLeagueRanking();
            LeagueRanking.Deserialize(reader);
            VictoryCount = reader.ReadVarUhShort();
            Fightcount = reader.ReadVarUhShort();
            NumFightNeededForLadder = reader.ReadShort();
        }

    }
}
