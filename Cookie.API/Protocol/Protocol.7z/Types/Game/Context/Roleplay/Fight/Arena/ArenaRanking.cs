﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class ArenaRanking : NetworkType
    {
        public const ushort ProtocolId = 554;
        public override ushort TypeID => ProtocolId;
        public ushort Rank { get; set; }
        public ushort BestRank { get; set; }

        public ArenaRanking(ushort rank, ushort bestRank)
        {
            Rank = rank;
            BestRank = bestRank;
        }

        public ArenaRanking() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhShort(Rank);
            writer.WriteVarUhShort(BestRank);
        }

        public override void Deserialize(IDataReader reader)
        {
            Rank = reader.ReadVarUhShort();
            BestRank = reader.ReadVarUhShort();
        }

    }
}
