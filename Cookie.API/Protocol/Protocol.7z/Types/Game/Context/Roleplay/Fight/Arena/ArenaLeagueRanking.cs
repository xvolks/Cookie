﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class ArenaLeagueRanking : NetworkType
    {
        public const ushort ProtocolId = 553;
        public override ushort TypeID => ProtocolId;
        public ushort Rank { get; set; }
        public ushort LeagueId { get; set; }
        public short LeaguePoints { get; set; }
        public short TotalLeaguePoints { get; set; }
        public int LadderPosition { get; set; }

        public ArenaLeagueRanking(ushort rank, ushort leagueId, short leaguePoints, short totalLeaguePoints, int ladderPosition)
        {
            Rank = rank;
            LeagueId = leagueId;
            LeaguePoints = leaguePoints;
            TotalLeaguePoints = totalLeaguePoints;
            LadderPosition = ladderPosition;
        }

        public ArenaLeagueRanking() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhShort(Rank);
            writer.WriteVarUhShort(LeagueId);
            writer.WriteVarShort(LeaguePoints);
            writer.WriteVarShort(TotalLeaguePoints);
            writer.WriteInt(LadderPosition);
        }

        public override void Deserialize(IDataReader reader)
        {
            Rank = reader.ReadVarUhShort();
            LeagueId = reader.ReadVarUhShort();
            LeaguePoints = reader.ReadVarShort();
            TotalLeaguePoints = reader.ReadVarShort();
            LadderPosition = reader.ReadInt();
        }

    }
}
