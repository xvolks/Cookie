﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class MonsterInGroupLightInformations : NetworkType
    {
        public const ushort ProtocolId = 395;
        public override ushort TypeID => ProtocolId;
        public int GenericId { get; set; }
        public byte Grade { get; set; }
        public short Level { get; set; }

        public MonsterInGroupLightInformations(int genericId, byte grade, short level)
        {
            GenericId = genericId;
            Grade = grade;
            Level = level;
        }

        public MonsterInGroupLightInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteInt(GenericId);
            writer.WriteByte(Grade);
            writer.WriteShort(Level);
        }

        public override void Deserialize(IDataReader reader)
        {
            GenericId = reader.ReadInt();
            Grade = reader.ReadByte();
            Level = reader.ReadShort();
        }

    }
}
