﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class GameRolePlayPrismInformations : GameRolePlayActorInformations
    {
        public new const ushort ProtocolId = 161;
        public override ushort TypeID => ProtocolId;
        public PrismInformation Prism { get; set; }

        public GameRolePlayPrismInformations(PrismInformation prism)
        {
            Prism = prism;
        }

        public GameRolePlayPrismInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteUShort(Prism.TypeID);
            Prism.Serialize(writer);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            Prism = ProtocolTypeManager.GetInstance<PrismInformation>(reader.ReadUShort());
            Prism.Deserialize(reader);
        }

    }
}
