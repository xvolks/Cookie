﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class PartyMemberInformations : CharacterBaseInformations
    {
        public new const ushort ProtocolId = 90;
        public override ushort TypeID => ProtocolId;
        public uint LifePoints { get; set; }
        public uint MaxLifePoints { get; set; }
        public ushort Prospecting { get; set; }
        public byte RegenRate { get; set; }
        public ushort Initiative { get; set; }
        public sbyte AlignmentSide { get; set; }
        public short WorldX { get; set; }
        public short WorldY { get; set; }
        public double MapId { get; set; }
        public ushort SubAreaId { get; set; }
        public PlayerStatus Status { get; set; }
        public List<PartyEntityBaseInformation> Entities { get; set; }

        public PartyMemberInformations(uint lifePoints, uint maxLifePoints, ushort prospecting, byte regenRate, ushort initiative, sbyte alignmentSide, short worldX, short worldY, double mapId, ushort subAreaId, PlayerStatus status, List<PartyEntityBaseInformation> entities)
        {
            LifePoints = lifePoints;
            MaxLifePoints = maxLifePoints;
            Prospecting = prospecting;
            RegenRate = regenRate;
            Initiative = initiative;
            AlignmentSide = alignmentSide;
            WorldX = worldX;
            WorldY = worldY;
            MapId = mapId;
            SubAreaId = subAreaId;
            Status = status;
            Entities = entities;
        }

        public PartyMemberInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteVarUhInt(LifePoints);
            writer.WriteVarUhInt(MaxLifePoints);
            writer.WriteVarUhShort(Prospecting);
            writer.WriteByte(RegenRate);
            writer.WriteVarUhShort(Initiative);
            writer.WriteSByte(AlignmentSide);
            writer.WriteShort(WorldX);
            writer.WriteShort(WorldY);
            writer.WriteDouble(MapId);
            writer.WriteVarUhShort(SubAreaId);
            writer.WriteUShort(Status.TypeID);
            Status.Serialize(writer);
            writer.WriteShort((short)Entities.Count);
            for (var entitiesIndex = 0; entitiesIndex < Entities.Count; entitiesIndex++)
            {
                var objectToSend = Entities[entitiesIndex];
                writer.WriteUShort(objectToSend.TypeID);
                objectToSend.Serialize(writer);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            LifePoints = reader.ReadVarUhInt();
            MaxLifePoints = reader.ReadVarUhInt();
            Prospecting = reader.ReadVarUhShort();
            RegenRate = reader.ReadByte();
            Initiative = reader.ReadVarUhShort();
            AlignmentSide = reader.ReadSByte();
            WorldX = reader.ReadShort();
            WorldY = reader.ReadShort();
            MapId = reader.ReadDouble();
            SubAreaId = reader.ReadVarUhShort();
            Status = ProtocolTypeManager.GetInstance<PlayerStatus>(reader.ReadUShort());
            Status.Deserialize(reader);
            var entitiesCount = reader.ReadUShort();
            Entities = new List<PartyEntityBaseInformation>();
            for (var entitiesIndex = 0; entitiesIndex < entitiesCount; entitiesIndex++)
            {
                var objectToAdd = ProtocolTypeManager.GetInstance<PartyEntityBaseInformation>(reader.ReadUShort());
                objectToAdd.Deserialize(reader);
                Entities.Add(objectToAdd);
            }
        }

    }
}
