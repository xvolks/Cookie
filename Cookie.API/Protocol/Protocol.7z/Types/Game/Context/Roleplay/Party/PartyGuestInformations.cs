﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class PartyGuestInformations : NetworkType
    {
        public const ushort ProtocolId = 374;
        public override ushort TypeID => ProtocolId;
        public ulong GuestId { get; set; }
        public ulong HostId { get; set; }
        public string Name { get; set; }
        public EntityLook GuestLook { get; set; }
        public sbyte Breed { get; set; }
        public bool Sex { get; set; }
        public PlayerStatus Status { get; set; }
        public List<PartyEntityBaseInformation> Entities { get; set; }

        public PartyGuestInformations(ulong guestId, ulong hostId, string name, EntityLook guestLook, sbyte breed, bool sex, PlayerStatus status, List<PartyEntityBaseInformation> entities)
        {
            GuestId = guestId;
            HostId = hostId;
            Name = name;
            GuestLook = guestLook;
            Breed = breed;
            Sex = sex;
            Status = status;
            Entities = entities;
        }

        public PartyGuestInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhLong(GuestId);
            writer.WriteVarUhLong(HostId);
            writer.WriteUTF(Name);
            GuestLook.Serialize(writer);
            writer.WriteSByte(Breed);
            writer.WriteBoolean(Sex);
            writer.WriteUShort(Status.TypeID);
            Status.Serialize(writer);
            writer.WriteShort((short)Entities.Count);
            for (var entitiesIndex = 0; entitiesIndex < Entities.Count; entitiesIndex++)
            {
                var objectToSend = Entities[entitiesIndex];
                objectToSend.Serialize(writer);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            GuestId = reader.ReadVarUhLong();
            HostId = reader.ReadVarUhLong();
            Name = reader.ReadUTF();
            GuestLook = new EntityLook();
            GuestLook.Deserialize(reader);
            Breed = reader.ReadSByte();
            Sex = reader.ReadBoolean();
            Status = ProtocolTypeManager.GetInstance<PlayerStatus>(reader.ReadUShort());
            Status.Deserialize(reader);
            var entitiesCount = reader.ReadUShort();
            Entities = new List<PartyEntityBaseInformation>();
            for (var entitiesIndex = 0; entitiesIndex < entitiesCount; entitiesIndex++)
            {
                var objectToAdd = new PartyEntityBaseInformation();
                objectToAdd.Deserialize(reader);
                Entities.Add(objectToAdd);
            }
        }

    }
}
