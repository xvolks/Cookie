﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class PartyEntityBaseInformation : NetworkType
    {
        public const ushort ProtocolId = 552;
        public override ushort TypeID => ProtocolId;
        public byte IndexId { get; set; }
        public byte EntityModelId { get; set; }
        public EntityLook EntityLook { get; set; }

        public PartyEntityBaseInformation(byte indexId, byte entityModelId, EntityLook entityLook)
        {
            IndexId = indexId;
            EntityModelId = entityModelId;
            EntityLook = entityLook;
        }

        public PartyEntityBaseInformation() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteByte(IndexId);
            writer.WriteByte(EntityModelId);
            EntityLook.Serialize(writer);
        }

        public override void Deserialize(IDataReader reader)
        {
            IndexId = reader.ReadByte();
            EntityModelId = reader.ReadByte();
            EntityLook = new EntityLook();
            EntityLook.Deserialize(reader);
        }

    }
}
