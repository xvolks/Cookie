﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class JobBookSubscription : NetworkType
    {
        public const ushort ProtocolId = 500;
        public override ushort TypeID => ProtocolId;
        public byte JobId { get; set; }
        public bool Subscribed { get; set; }

        public JobBookSubscription(byte jobId, bool subscribed)
        {
            JobId = jobId;
            Subscribed = subscribed;
        }

        public JobBookSubscription() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteByte(JobId);
            writer.WriteBoolean(Subscribed);
        }

        public override void Deserialize(IDataReader reader)
        {
            JobId = reader.ReadByte();
            Subscribed = reader.ReadBoolean();
        }

    }
}
