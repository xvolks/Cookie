﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class ShortcutSpell : Shortcut
    {
        public new const ushort ProtocolId = 368;
        public override ushort TypeID => ProtocolId;
        public ushort SpellId { get; set; }

        public ShortcutSpell(ushort spellId)
        {
            SpellId = spellId;
        }

        public ShortcutSpell() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteVarUhShort(SpellId);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            SpellId = reader.ReadVarUhShort();
        }

    }
}
