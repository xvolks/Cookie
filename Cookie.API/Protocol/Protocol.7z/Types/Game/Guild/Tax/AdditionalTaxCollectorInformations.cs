﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class AdditionalTaxCollectorInformations : NetworkType
    {
        public const ushort ProtocolId = 165;
        public override ushort TypeID => ProtocolId;
        public string CollectorCallerName { get; set; }
        public int Date { get; set; }

        public AdditionalTaxCollectorInformations(string collectorCallerName, int date)
        {
            CollectorCallerName = collectorCallerName;
            Date = date;
        }

        public AdditionalTaxCollectorInformations() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteUTF(CollectorCallerName);
            writer.WriteInt(Date);
        }

        public override void Deserialize(IDataReader reader)
        {
            CollectorCallerName = reader.ReadUTF();
            Date = reader.ReadInt();
        }

    }
}
