﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class ItemForPreset : NetworkType
    {
        public const ushort ProtocolId = 540;
        public override ushort TypeID => ProtocolId;
        public short Position { get; set; }
        public ushort ObjGid { get; set; }
        public uint ObjUid { get; set; }

        public ItemForPreset(short position, ushort objGid, uint objUid)
        {
            Position = position;
            ObjGid = objGid;
            ObjUid = objUid;
        }

        public ItemForPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteShort(Position);
            writer.WriteVarUhShort(ObjGid);
            writer.WriteVarUhInt(ObjUid);
        }

        public override void Deserialize(IDataReader reader)
        {
            Position = reader.ReadShort();
            ObjGid = reader.ReadVarUhShort();
            ObjUid = reader.ReadVarUhInt();
        }

    }
}
