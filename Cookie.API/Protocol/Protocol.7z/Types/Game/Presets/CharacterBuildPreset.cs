﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class CharacterBuildPreset : PresetsContainerPreset
    {
        public new const ushort ProtocolId = 534;
        public override ushort TypeID => ProtocolId;
        public short IconId { get; set; }
        public string Name { get; set; }

        public CharacterBuildPreset(short iconId, string name)
        {
            IconId = iconId;
            Name = name;
        }

        public CharacterBuildPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteShort(IconId);
            writer.WriteUTF(Name);
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            IconId = reader.ReadShort();
            Name = reader.ReadUTF();
        }

    }
}
