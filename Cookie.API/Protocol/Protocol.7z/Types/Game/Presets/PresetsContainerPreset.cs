﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class PresetsContainerPreset : Preset
    {
        public new const ushort ProtocolId = 520;
        public override ushort TypeID => ProtocolId;
        public List<Preset> Presets { get; set; }

        public PresetsContainerPreset(List<Preset> presets)
        {
            Presets = presets;
        }

        public PresetsContainerPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteShort((short)Presets.Count);
            for (var presetsIndex = 0; presetsIndex < Presets.Count; presetsIndex++)
            {
                var objectToSend = Presets[presetsIndex];
                writer.WriteUShort(objectToSend.TypeID);
                objectToSend.Serialize(writer);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            var presetsCount = reader.ReadUShort();
            Presets = new List<Preset>();
            for (var presetsIndex = 0; presetsIndex < presetsCount; presetsIndex++)
            {
                var objectToAdd = ProtocolTypeManager.GetInstance<Preset>(reader.ReadUShort());
                objectToAdd.Deserialize(reader);
                Presets.Add(objectToAdd);
            }
        }

    }
}
