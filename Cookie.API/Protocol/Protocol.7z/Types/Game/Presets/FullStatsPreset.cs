﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class FullStatsPreset : Preset
    {
        public new const ushort ProtocolId = 532;
        public override ushort TypeID => ProtocolId;
        public List<CharacterCharacteristicForPreset> Stats { get; set; }

        public FullStatsPreset(List<CharacterCharacteristicForPreset> stats)
        {
            Stats = stats;
        }

        public FullStatsPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteShort((short)Stats.Count);
            for (var statsIndex = 0; statsIndex < Stats.Count; statsIndex++)
            {
                var objectToSend = Stats[statsIndex];
                objectToSend.Serialize(writer);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            var statsCount = reader.ReadUShort();
            Stats = new List<CharacterCharacteristicForPreset>();
            for (var statsIndex = 0; statsIndex < statsCount; statsIndex++)
            {
                var objectToAdd = new CharacterCharacteristicForPreset();
                objectToAdd.Deserialize(reader);
                Stats.Add(objectToAdd);
            }
        }

    }
}
