﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class Preset : NetworkType
    {
        public const ushort ProtocolId = 355;
        public override ushort TypeID => ProtocolId;
        public short ObjectId { get; set; }

        public Preset(short objectId)
        {
            ObjectId = objectId;
        }

        public Preset() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteShort(ObjectId);
        }

        public override void Deserialize(IDataReader reader)
        {
            ObjectId = reader.ReadShort();
        }

    }
}
