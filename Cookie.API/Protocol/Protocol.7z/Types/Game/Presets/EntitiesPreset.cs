﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class EntitiesPreset : Preset
    {
        public new const ushort ProtocolId = 545;
        public override ushort TypeID => ProtocolId;
        public short IconId { get; set; }
        public List<ushort> EntityIds { get; set; }

        public EntitiesPreset(short iconId, List<ushort> entityIds)
        {
            IconId = iconId;
            EntityIds = entityIds;
        }

        public EntitiesPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteShort(IconId);
            writer.WriteShort((short)EntityIds.Count);
            for (var entityIdsIndex = 0; entityIdsIndex < EntityIds.Count; entityIdsIndex++)
            {
                writer.WriteVarUhShort(EntityIds[entityIdsIndex]);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            IconId = reader.ReadShort();
            var entityIdsCount = reader.ReadUShort();
            EntityIds = new List<ushort>();
            for (var entityIdsIndex = 0; entityIdsIndex < entityIdsCount; entityIdsIndex++)
            {
                EntityIds.Add(reader.ReadVarUhShort());
            }
        }

    }
}
