﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class SpellForPreset : NetworkType
    {
        public const ushort ProtocolId = 557;
        public override ushort TypeID => ProtocolId;
        public ushort SpellId { get; set; }
        public List<short> Shortcuts { get; set; }

        public SpellForPreset(ushort spellId, List<short> shortcuts)
        {
            SpellId = spellId;
            Shortcuts = shortcuts;
        }

        public SpellForPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhShort(SpellId);
            writer.WriteShort((short)Shortcuts.Count);
            for (var shortcutsIndex = 0; shortcutsIndex < Shortcuts.Count; shortcutsIndex++)
            {
                writer.WriteShort(Shortcuts[shortcutsIndex]);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            SpellId = reader.ReadVarUhShort();
            var shortcutsCount = reader.ReadUShort();
            Shortcuts = new List<short>();
            for (var shortcutsIndex = 0; shortcutsIndex < shortcutsCount; shortcutsIndex++)
            {
                Shortcuts.Add(reader.ReadShort());
            }
        }

    }
}
