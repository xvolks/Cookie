﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class IdolsPreset : Preset
    {
        public new const ushort ProtocolId = 491;
        public override ushort TypeID => ProtocolId;
        public short IconId { get; set; }
        public List<ushort> IdolIds { get; set; }

        public IdolsPreset(short iconId, List<ushort> idolIds)
        {
            IconId = iconId;
            IdolIds = idolIds;
        }

        public IdolsPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteShort(IconId);
            writer.WriteShort((short)IdolIds.Count);
            for (var idolIdsIndex = 0; idolIdsIndex < IdolIds.Count; idolIdsIndex++)
            {
                writer.WriteVarUhShort(IdolIds[idolIdsIndex]);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            IconId = reader.ReadShort();
            var idolIdsCount = reader.ReadUShort();
            IdolIds = new List<ushort>();
            for (var idolIdsIndex = 0; idolIdsIndex < idolIdsCount; idolIdsIndex++)
            {
                IdolIds.Add(reader.ReadVarUhShort());
            }
        }

    }
}
