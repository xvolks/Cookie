﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class SpellsPreset : Preset
    {
        public new const ushort ProtocolId = 519;
        public override ushort TypeID => ProtocolId;
        public List<SpellForPreset> Spells { get; set; }

        public SpellsPreset(List<SpellForPreset> spells)
        {
            Spells = spells;
        }

        public SpellsPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteShort((short)Spells.Count);
            for (var spellsIndex = 0; spellsIndex < Spells.Count; spellsIndex++)
            {
                var objectToSend = Spells[spellsIndex];
                objectToSend.Serialize(writer);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            var spellsCount = reader.ReadUShort();
            Spells = new List<SpellForPreset>();
            for (var spellsIndex = 0; spellsIndex < spellsCount; spellsIndex++)
            {
                var objectToAdd = new SpellForPreset();
                objectToAdd.Deserialize(reader);
                Spells.Add(objectToAdd);
            }
        }

    }
}
