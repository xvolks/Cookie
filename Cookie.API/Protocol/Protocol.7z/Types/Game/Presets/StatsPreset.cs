﻿namespace Cookie.API.Protocol.Network.Messages
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Types;

    public class StatsPreset : Preset
    {
        public new const ushort ProtocolId = 521;
        public override ushort TypeID => ProtocolId;
        public List<SimpleCharacterCharacteristicForPreset> Stats { get; set; }

        public StatsPreset(List<SimpleCharacterCharacteristicForPreset> stats)
        {
            Stats = stats;
        }

        public StatsPreset() { }

        public override void Serialize(IDataWriter writer)
        {
            base.Serialize(writer);
            writer.WriteShort((short)Stats.Count);
            for (var statsIndex = 0; statsIndex < Stats.Count; statsIndex++)
            {
                var objectToSend = Stats[statsIndex];
                objectToSend.Serialize(writer);
            }
        }

        public override void Deserialize(IDataReader reader)
        {
            base.Deserialize(reader);
            var statsCount = reader.ReadUShort();
            Stats = new List<SimpleCharacterCharacteristicForPreset>();
            for (var statsIndex = 0; statsIndex < statsCount; statsIndex++)
            {
                var objectToAdd = new SimpleCharacterCharacteristicForPreset();
                objectToAdd.Deserialize(reader);
                Stats.Add(objectToAdd);
            }
        }

    }
}
