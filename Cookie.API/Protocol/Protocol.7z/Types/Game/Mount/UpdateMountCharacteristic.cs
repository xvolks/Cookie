﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class UpdateMountCharacteristic : NetworkType
    {
        public const ushort ProtocolId = 536;
        public override ushort TypeID => ProtocolId;
        public byte Type { get; set; }

        public UpdateMountCharacteristic(byte type)
        {
            Type = type;
        }

        public UpdateMountCharacteristic() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteByte(Type);
        }

        public override void Deserialize(IDataReader reader)
        {
            Type = reader.ReadByte();
        }

    }
}
