﻿namespace Cookie.API.Protocol.Network.Types
{
    using Utils.IO;
    using Cookie.API.Protocol.Enums;
    using System.Collections.Generic;
    using Cookie.API.Protocol.Network.Messages;

    public class RecycledItem : NetworkType
    {
        public const ushort ProtocolId = 547;
        public override ushort TypeID => ProtocolId;
        public ushort ObjectId { get; set; }
        public uint Qty { get; set; }

        public RecycledItem(ushort objectId, uint qty)
        {
            ObjectId = objectId;
            Qty = qty;
        }

        public RecycledItem() { }

        public override void Serialize(IDataWriter writer)
        {
            writer.WriteVarUhShort(ObjectId);
            writer.WriteUInt(Qty);
        }

        public override void Deserialize(IDataReader reader)
        {
            ObjectId = reader.ReadVarUhShort();
            Qty = reader.ReadUInt();
        }

    }
}
