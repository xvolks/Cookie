﻿using Cookie.IO;
using Cookie.Protocol.Network.Messages.Game.Approach;
using java.io;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cookie.Protocol.Network.Messages.Connection
{
    public class SelectedServerDataMessage : NetworkMessage
    {
        public const uint ProtocolId = 42;
        public override uint MessageID { get { return ProtocolId; } }

        public ushort ServerId;
        public string Address;
        public ushort Port;
        public bool CanCreateNewCharacter = false;
        public string Ticket;

        public SelectedServerDataMessage() { }

        public SelectedServerDataMessage(ushort serverId, string address, ushort port, bool canCreateNewCharacter, string ticket)
        {
            ServerId = serverId;
            Address = address;
            Port = port;
            CanCreateNewCharacter = canCreateNewCharacter;
            Ticket = ticket;
        }

        public override void Serialize(ICustomDataOutput writer)
        {
            writer.WriteVarUhShort(ServerId);
            writer.WriteUTF(Address);
            writer.WriteUShort(1);
            writer.WriteInt(Port);
            writer.WriteBoolean(CanCreateNewCharacter);
            writer.WriteUTF(Ticket);
        }

        public override void Deserialize(ICustomDataInput reader)
        {
            ServerId = reader.ReadVarUhShort();
            Address = reader.ReadUTF();
            ushort aux = reader.ReadUShort();
            for(ushort i = 0; i < aux; i++)
            {
                Port = (ushort)reader.ReadInt();
            }
            CanCreateNewCharacter = reader.ReadBoolean();
            ushort ticketLenght = (ushort)reader.ReadByte();
            List<String> lazyness = new List<String>();
            for (ushort i = 0; i < ticketLenght; i++)
                lazyness.Add(reader.ReadByte().ToString());
            Ticket = String.Join(",", lazyness.ToArray());
            lazyness.Clear();
        }
    }
}
