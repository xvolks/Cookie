﻿using Cookie.IO;

namespace Cookie.Protocol.Network.Messages.Game.Approach
{
    class ServerSettingsMessage : NetworkMessage
    {
        public const uint ProtocolId = 6340;
        public override uint MessageID { get { return ProtocolId; } }

        public string Lang;
        public byte Community;
        public byte GameType;
        public bool IsMonoAccount;
        public ushort ArenaLeaveBanTime;
        public int ItemMaxLevel;
        public bool HasFreeAutopilot;

        public ServerSettingsMessage() { }

        public ServerSettingsMessage(string lang, byte community, byte gameType, ushort arenaLeaveBanTime)
        {
            Lang = lang;
            Community = community;
            GameType = gameType;
            ArenaLeaveBanTime = arenaLeaveBanTime;
        }

        public override void Serialize(ICustomDataOutput writer)
        {
            byte Flag = 0x00;
            Flag = BooleanByteWrapper.SetFlag(Flag, 0, IsMonoAccount);
            Flag = BooleanByteWrapper.SetFlag(Flag, 1, HasFreeAutopilot);
            writer.WriteByte(Flag);
            writer.WriteUTF(Lang);
            writer.WriteByte(Community);
            writer.WriteByte(GameType);
            writer.WriteVarUhShort(ArenaLeaveBanTime);
            writer.WriteInt(ItemMaxLevel);
        }

        public override void Deserialize(ICustomDataInput reader)
        {
            byte flag1 = reader.ReadByte();
            IsMonoAccount = BooleanByteWrapper.GetFlag(flag1, 0);
            HasFreeAutopilot = BooleanByteWrapper.GetFlag(flag1, 1);
            Lang = reader.ReadUTF();
            Community = reader.ReadByte();
            GameType = reader.ReadByte();
            ArenaLeaveBanTime = reader.ReadVarUhShort();
            ItemMaxLevel = reader.ReadInt();
        }
    }
}
