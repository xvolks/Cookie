

// Generated on 12/06/2016 11:35:49
using System;
using System.Collections.Generic;
using Cookie.Gamedata.D2o;

namespace Cookie.Datacenter
{
    [D2oClass("AlignmentEffect")]
    public class AlignmentEffect : IDataObject
    {
        public const String MODULE = "AlignmentEffect";
        public int Id;
        public uint CharacteristicId;
        public uint DescriptionId;
    }
}