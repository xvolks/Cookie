

// Generated on 12/06/2016 11:35:50
using System;
using System.Collections.Generic;
using Cookie.Gamedata.D2o;

namespace Cookie.Datacenter
{
    [D2oClass("Comics")]
    public class Comic : IDataObject
    {
        private const String MODULE = "Comics";
        public int Id;
        public String RemoteId;
    }
}