using Cookie.Gamedata.D2o;
using System;

namespace Cookie.Datacenter
{
    [D2oClass("IdolsPresetIcons")]
    public class IdolsPresetIcon
    {
        public const String MODULE = "IdolsPresetIcons";
        public int Id;
        public int Order;
    }
}