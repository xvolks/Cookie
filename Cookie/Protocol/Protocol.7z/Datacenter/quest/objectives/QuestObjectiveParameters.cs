

// Generated on 12/06/2016 11:35:52
using System;
using System.Collections.Generic;
using Cookie.Gamedata.D2o;

namespace Cookie.Datacenter
{
    [D2oClass("QuestObjectiveParameters")]
    public class QuestObjectiveParameters : IDataObject
    {
        public uint NumParams;
        public int Parameter0;
        public int Parameter1;
        public int Parameter2;
        public int Parameter3;
        public int Parameter4;
        public Boolean DungeonOnly;
    }
}