

// Generated on 12/06/2016 11:35:51
using Cookie.Gamedata.D2o;
using Cookie.GameData.D2O;

namespace Cookie.Datacenter
{
    [D2oClass("AnimFunMonsterData")]
    public class AnimFunMonsterData : AnimFunData
    {
    }
}