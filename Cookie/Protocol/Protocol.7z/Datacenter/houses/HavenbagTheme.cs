

// Generated on 12/06/2016 11:35:50
using System;
using System.Collections.Generic;
using Cookie.Gamedata.D2o;

namespace Cookie.Datacenter
{
    [D2oClass("HavenbagThemes")]
    public class HavenbagTheme : IDataObject
    {
        public const String MODULE = "HavenbagThemes";
        public int Id;
        public int NameId;
        public int MapId;
    }
}